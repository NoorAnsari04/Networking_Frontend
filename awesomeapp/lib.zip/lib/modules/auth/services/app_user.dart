import 'dart:convert';

import 'package:hive/hive.dart';

part 'app_user.g.dart';

@HiveType(typeId: 0)
class AppUser {
  @HiveField(0)
  String id;

  @HiveField(1)
  String name;

  @HiveField(2)
  String lastName;

  @HiveField(3)
  String email;

  @HiveField(4)
  String? imageUrl;

  @HiveField(5)
  String? company;

  @HiveField(6)
  String? position;

  @HiveField(7)
  String? sessionsDeliver;

  @HiveField(8)
  String? description;

  @HiveField(9)
  String? experience;

  @HiveField(10)
  String? linkedinUrl;

  @HiveField(11)
  String? degreeProgram;

  @HiveField(12)
  String? yearOfGraduation;

  @HiveField(13)
  String? instituteName;

  @HiveField(14)
  String? accessToken;

  @HiveField(15)
  String? refreshToken;

  bool isReceivedRequest;

  // New fields (not saved in Hive)
  bool? isStudent;

  List<String>? interests;

  AppUser({
    required this.id,
    required this.name,
    required this.email,
    required this.lastName,
    required this.position,
    required this.company,
    required this.description,
    required this.imageUrl,
    required this.experience,
    required this.linkedinUrl,
    required this.sessionsDeliver,
    this.isReceivedRequest = false,
    this.isStudent,
    required this.degreeProgram,
    required this.yearOfGraduation,
    required this.instituteName,
    this.interests,
    this.accessToken,
    this.refreshToken
  });

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      id: json['id'] ?? '',
      name: json['name'] ?? '',
      email: json['email'] ?? '',
      lastName: json['lastName'] ?? '',
      position: json['position'],
      company: json['company'],
      description: json['description'],
      imageUrl: json['imageUrl'],
      sessionsDeliver: json['sessionsDeliver'],
      experience: json['experience'],
      linkedinUrl: json['linkedinUrl'],
      isReceivedRequest: json['isReceivedRequest'] ?? false,
      isStudent: json['isStudent'] ?? false,
      degreeProgram: json['degreeProgram'],
      yearOfGraduation: json['yearOfGraduation'],
      instituteName: json['instituteName'],
      interests: (json['interests'] as List<dynamic>?)?.cast<String>(),
      accessToken: json['accessToken'],
      refreshToken: json['refreshToken'],
    );
  }

  String get fullName => name + ' $lastName';
  // String? get getAccessToken => accessToken; 
  // String? get getRefreshToken => refreshToken; 
  AppUser copyWith({
    String? id,
    String? name,
    String? lastName,
    String? email,
    String? imageUrl,
    String? company,
    String? position,
    String? sessionsDeliver,
    String? description,
    String? experience,
    String? linkedinUrl,
    bool? isReceivedRequest,
    bool? isStudent,
    String? degreeProgram,
    String? yearOfGraduation,
    String? instituteName,
    List<String>? interests,
    String? accessToken,
    String? refreshToken,
  }) {
    return AppUser(
      id: id ?? this.id,
      name: name ?? this.name,
      lastName: lastName ?? this.lastName,
      email: email ?? this.email,
      imageUrl: imageUrl ?? this.imageUrl,
      company: company ?? this.company,
      position: position ?? this.position,
      sessionsDeliver: sessionsDeliver ?? this.sessionsDeliver,
      description: description ?? this.description,
      experience: experience ?? this.experience,
      linkedinUrl: linkedinUrl ?? this.linkedinUrl,
      isReceivedRequest: isReceivedRequest ?? this.isReceivedRequest,
      isStudent: isStudent ?? this.isStudent,
      degreeProgram: degreeProgram ?? this.degreeProgram,
      yearOfGraduation: yearOfGraduation ?? this.yearOfGraduation,
      instituteName: instituteName ?? this.instituteName,
      interests: interests ?? this.interests,
      accessToken: accessToken ?? this.accessToken,
      refreshToken: refreshToken ?? this.refreshToken,
    );
  }
}
