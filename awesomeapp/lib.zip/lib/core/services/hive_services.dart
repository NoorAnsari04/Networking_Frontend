import 'package:hive/hive.dart';

import '../../modules/auth/services/app_user.dart';

class HiveService {
  static const String userBoxName = 'userBox';
  static const String tokenBoxName = 'tokenBox';
  static const String userKey = 'user';
  static const String accessTokenKey = 'accessToken';
  static const String refreshTokenKey = 'refreshToken';

  static Future<void> init() async {
    Hive.registerAdapter(AppUserAdapter());
    await Hive.openBox<AppUser>(userBoxName);
    await Hive.openBox<String>(tokenBoxName);
  }

  Box<AppUser> get _userBox => Hive.box<AppUser>(userBoxName);
  Box<String> get _tokenBox => Hive.box<String>(tokenBoxName);

  void saveUser(AppUser user) {
    _userBox.put(userKey, user);
    saveAccessToken(user.accessToken ?? '');
  }

  AppUser? getUser() {
    return _userBox.get(userKey);
  }

  void deleteUser() {
    _userBox.delete(userKey);
  }

  Future<void> saveAccessToken(String token) async {
    await _tokenBox.put(accessTokenKey, token);
  }

  Future<void> saveRefreshToken(String token) async {
    await _tokenBox.put(refreshTokenKey, token);
  }

  String? getAccessToken(){
    return _tokenBox.get(accessTokenKey);
  }

  String? getRefreshToken(){
    return _tokenBox.get(refreshTokenKey);
  }

  Future<void> deleteTokens()async{
    await _tokenBox.delete(accessTokenKey);
    await _tokenBox.delete(refreshTokenKey);
  }
}
