import '../environment/config.dart';

class NetworkConfiguration {
  static String baseUrl =  Environment.baseUrl;
  static const timeoutDuration = Duration(seconds: 10);
}