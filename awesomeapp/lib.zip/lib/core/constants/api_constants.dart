class ApiConstants {
  static const String baseUrl = 'http://192.168.100.42:3000';
  static const String login = '/api/auth/login/';
  static const String signUp = '/api/auth/signup/';
  static const String userDetails = '/api/user/update';
  static const String refreshToken = '/api/auth/refresh';
  static const int connectTimeout = 5000;
  static const int receiveTimeout = 3000;
}